<template>
  <div class="about">
    <h1>Henrique Medeiros Sabino</h1>
    <h1>RA: 1976730</h1>
    <h1>Analise e desenvolvimento de sistemas</h1>
    <h1>3º termo - C</h1>
  </div>
</template>
